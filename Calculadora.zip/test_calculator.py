import unittest
from calculator import Calculadora

class TestCalculadora(unittest.TestCase):
    def setUp(self):
        self.calc = Calculadora()
    
    def test_suma(self):
        self.calc.entrada.set("2+2")
        self.calc.click_boton('=')
        self.assertEqual(self.calc.entrada.get(), "4")
    
    def test_resta(self):
        self.calc.entrada.set("5-3")
        self.calc.click_boton('=')
        self.assertEqual(self.calc.entrada.get(), "2")
    
    def test_multiplicacion(self):
        self.calc.entrada.set("4*3")
        self.calc.click_boton('=')
        self.assertEqual(self.calc.entrada.get(), "12")
    
    def test_division(self):
        self.calc.entrada.set("10/2")
        self.calc.click_boton('=')
        self.assertEqual(self.calc.entrada.get(), "5")
    
    def test_division_por_cero(self):
        self.calc.entrada.set("5/0")
        self.calc.click_boton('=')
        self.assertEqual(self.calc.entrada.get(), "Error: División por cero")
    
    def test_raiz_cuadrada(self):
        self.calc.entrada.set("16")
        self.calc.click_boton('√')
        self.assertEqual(self.calc.entrada.get(), "4")
    
    def test_cuadrado(self):
        self.calc.entrada.set("3")
        self.calc.click_boton('²')
        self.assertEqual(self.calc.entrada.get(), "9")
    
    def test_limpiar(self):
        self.calc.entrada.set("123")
        self.calc.limpiar()
        self.assertEqual(self.calc.entrada.get(), "")
    
    def test_retroceso(self):
        self.calc.entrada.set("123")
        self.calc.click_boton('⌫')
        self.assertEqual(self.calc.entrada.get(), "12")

if __name__ == '__main__':
    unittest.main()