import tkinter as tk
from ttkbootstrap import Style, ttk
import math
import os

class Calculadora:
    def __init__(self):
        # Crear ventana principal con estilo bootstrap
        self.ventana = tk.Tk()
        self.style = Style(theme='darkly')
        # Personalizar la ventana
        self.ventana.title("Calculadora Moderna")
        self.ventana.configure(bg=self.style.colors.bg)
        
        # Hacer que la ventana sea redimensionable
        self.ventana.resizable(True, True)
        
        # Establecer un tamaño mínimo
        self.ventana.minsize(300, 400)
        self.entrada = tk.StringVar()
        self.historial = []
        
        # Frame principal
        frame_principal = ttk.Frame(self.ventana)
        frame_principal.grid(row=0, column=0, sticky='nsew')
        
        # Botón de ajustes
        self.btn_ajustes = ttk.Button(
            frame_principal,
            text='⚙',
            command=self.mostrar_ajustes,
            style='secondary.TButton',
            width=3
        )
        self.btn_ajustes.grid(row=0, column=0, padx=5, pady=5, sticky='w')
        
        # Botón de historial
        self.btn_historial = ttk.Button(
            frame_principal,
            text='📋',
            command=self.mostrar_historial,
            style='secondary.TButton',
            width=3
        )
        self.btn_historial.grid(row=0, column=3, padx=5, pady=5, sticky='e')
        
        # Crear display
        self.display = ttk.Entry(
            frame_principal, 
            textvariable=self.entrada, 
            justify='right',
            font=('Rex', 24)  # Aumentado el tamaño de la fuente
        )
        self.display.grid(row=1, column=0, columnspan=4, padx=10, pady=10, sticky='nsew')
        
        # Definir botones
        botones = [
            '1', '2', '3', '/',
            '4', '5', '6', '*',
            '7', '8', '9', '-',
            '0', '.', '=', '+'
    ]
        
        # Botones adicionales para funciones especiales
        botones_especiales = ['√', '²', '(', ')']
        
        # Crear y posicionar botones especiales
        fila = 2
        columna = 0
        for boton in botones_especiales:
            comando = lambda x=boton: self.click_boton(x)
            ttk.Button(
                frame_principal,  # Cambiado a frame_principal
                text=boton,
                command=comando,
                style='info.TButton',
                width=3  # Ajustado el ancho
            ).grid(row=fila, column=columna, padx=5, pady=5, sticky='nsew')
            columna += 1
        
        # Crear y posicionar botones normales
        fila = 3
        columna = 0
        for boton in botones:
            comando = lambda x=boton: self.click_boton(x)
            ttk.Button(
                frame_principal,  # Cambiado a frame_principal
                text=boton,
                command=comando,
                style='primary.TButton',
                width=3  # Ajustado el ancho
            ).grid(row=fila, column=columna, padx=5, pady=5, sticky='nsew')
            columna += 1
            if columna > 3:
                columna = 0
                fila += 1
        
        # Crear frame para botones de borrado
        frame_borrado = ttk.Frame(frame_principal)  # Cambiado a frame_principal
        frame_borrado.grid(row=7, column=0, columnspan=4, padx=8, pady=8, sticky='nsew')
        
        # Botón para limpiar
        ttk.Button(
            frame_borrado,
            text='C',
            command=self.limpiar,
            style='danger.TButton',
            width=14  # Aumentado el ancho
        ).pack(side='left', padx=5, expand=True)
        
        # Botón de retroceso
        ttk.Button(
            frame_borrado,
            text='⌫',
            command=lambda: self.click_boton('⌫'),
            style='danger.TButton',
            width=14  # Aumentado el ancho
        ).pack(side='left', padx=5, expand=True)
        
        # Configurar expansión de filas y columnas
        for i in range(8):
            self.ventana.grid_rowconfigure(i, weight=1)
        for i in range(4):
            self.ventana.grid_columnconfigure(i, weight=1)
    
    def cambiar_tema(self, tema):
        self.style.theme_use(tema)
    
    def mostrar_ajustes(self):
        # Ventana de ajustes
        ventana_ajustes = tk.Toplevel(self.ventana)
        ventana_ajustes.title("Ajustes")
        ventana_ajustes.geometry("300x200")
        
        # Frame para temas
        frame_tema = ttk.LabelFrame(ventana_ajustes, text="Temas")
        frame_tema.pack(padx=10, pady=10, fill='x')
        
        temas = [
            'darkly',     # Oscuro clásico
            'solar',      # Oscuro ámbar
            'superhero',  # Oscuro azul
            'vapor',      # Oscuro púrpura
            'cyborg',     # Oscuro tecnológico
            'morph',      # Oscuro moderno
            'pulse'       # Oscuro con acentos
        ]
        
        tema_combo = ttk.Combobox(frame_tema, values=temas, width=20)
        tema_combo.set(self.style.theme.name)
        tema_combo.pack(padx=10, pady=10)
        tema_combo.bind('<<ComboboxSelected>>', lambda e: self.cambiar_tema(tema_combo.get()))
    
    def mostrar_historial(self):
        # Ventana de historial
        ventana_historial = tk.Toplevel(self.ventana)
        ventana_historial.title("Historial")
        ventana_historial.geometry("300x400")
        
        # Lista de historial
        frame_lista = ttk.Frame(ventana_historial)
        frame_lista.pack(padx=10, pady=10, fill='both', expand=True)
        
        scrollbar = ttk.Scrollbar(frame_lista)
        scrollbar.pack(side='right', fill='y')
        
        lista = tk.Listbox(
            frame_lista,
            yscrollcommand=scrollbar.set,
            font=('Rex', 12),
            bg=self.style.colors.bg,
            fg=self.style.colors.fg
        )
        lista.pack(side='left', fill='both', expand=True)
        
        scrollbar.config(command=lista.yview)
        
        # Llenar lista con historial
        for calculo in self.historial:
            lista.insert('end', calculo)
        
        # Botón para limpiar historial
        ttk.Button(
            ventana_historial,
            text="Limpiar Historial",
            command=lambda: [self.historial.clear(), lista.delete(0, 'end')],
            style='danger.TButton'
        ).pack(pady=10)
    
    def click_boton(self, caracter):
        if caracter == '=':
            try:
                expresion = self.entrada.get()
                if not expresion:
                    return
                resultado = eval(expresion)
                if isinstance(resultado, (int, float)):
                    if resultado.is_integer():
                        resultado = int(resultado)
                self.entrada.set(resultado)
                # Agregar al historial
                self.historial.append(f"{expresion} = {resultado}")
            except:
                self.entrada.set('Error')
        elif caracter == '√':
            try:
                numero = float(self.entrada.get())
                if numero >= 0:
                    resultado = math.sqrt(numero)
                    # Verificar si la raíz es un número entero
                    if resultado.is_integer():
                        resultado = int(resultado)
                    self.entrada.set(resultado)
                else:
                    self.entrada.set('Error')
            except:
                self.entrada.set('Error')
        elif caracter == '²':
            try:
                numero = float(self.entrada.get())
                resultado = numero ** 2
                # Verificar si el cuadrado es un número entero
                if resultado.is_integer():
                    resultado = int(resultado)
                self.entrada.set(resultado)
            except:
                self.entrada.set('Error')
        elif caracter == '⌫':
            texto_actual = self.entrada.get()
            if texto_actual:
                self.entrada.set(texto_actual[:-1])
        elif caracter == '√':
            try:
                numero = float(self.entrada.get())
                if numero >= 0:
                    resultado = math.sqrt(numero)
                    # Verificar si la raíz es un número entero
                    if resultado.is_integer():
                        resultado = int(resultado)
                    self.entrada.set(resultado)
                else:
                    self.entrada.set('Error')
            except:
                self.entrada.set('Error')
        elif caracter == '²':
            try:
                numero = float(self.entrada.get())
                resultado = numero ** 2
                # Verificar si el cuadrado es un número entero
                if resultado.is_integer():
                    resultado = int(resultado)
                self.entrada.set(resultado)
            except:
                self.entrada.set('Error')
        else:
            self.entrada.set(self.entrada.get() + caracter)
    
    def limpiar(self):
        self.entrada.set('')
    
    def iniciar(self):
        self.ventana.mainloop()

# Crear e iniciar la calculadora
if __name__ == '__main__':
    calc = Calculadora()
    calc.iniciar()